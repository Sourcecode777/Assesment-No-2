**Assessment 2: Development with Kotlin**

Build a basic app using Kotlin with the following specifications:

*Your own App name
*Slash screen with own background colour
*Navigational Drawer with menu items
*Dashboard has buttons that links to 3 other screens on click
